package com.exe;

public class DemoArithmeticExe {

	public static void main(String[] args) {
		//declaring variables
		int a,b,c;
		a=10;
		b=10;
		System.out.println("start of the pgm");
		try {
			//performing arithmetic operation
			c=a/b;
			System.out.println("c="+c);
			//accessing an element outside the array bounds
			int arr[]= {1,2,3};
			System.out.println(arr[4]);//this will throw an ArrayIndexOutOfBoundsException
			} catch(ArithmeticException ae) {
				System.out.println("Exception caught");
			} catch(ArrayIndexOutOfBoundsException ae) {
			System.out.println("Array Exception caught");
		} finally {
			//this block always executes, regardless of exceptions
		System.out.println("end of the pgm");
		}
		
	}

}
