package com.Anudip;
class MyThread extends Thread {
    public void run() {
        System.out.println("Thread running using Thread class: " + Thread.currentThread().getName());
    }
}

public class ThreadExample {
    public static void main(String[] args) {
        int numberOfThreads = 5;
        
        for (int i = 1; i <= numberOfThreads; i++) {
            MyThread thread = new MyThread();
            thread.start();
        }
    }
}