package com.Anudip;
class MyRunnable implements Runnable {
    public void run() {
        System.out.println("Thread running using Runnable interface: " + Thread.currentThread().getName());
    }
}

public class RunnableExample {
    public static void main(String[] args) {
        int numberOfThreads = 5;
        
        for (int i = 1; i <= numberOfThreads; i++) {
            Thread thread = new Thread(new MyRunnable());
            thread.start();
        }
    }
}
