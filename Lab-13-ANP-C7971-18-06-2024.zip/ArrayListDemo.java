package com.Collections;
import java.util.ArrayList;
import java.util.List;

public class ArrayListDemo {

	public static void main(String[] args) {
		//Creating an ArrayList with Object type elements
		ArrayList<Object> list=new ArrayList<>();
		//Adding elements to the ArrayList
		list.add(3);
		list.add(7);
		list.add(2);
		list.add('n');
		list.add(7.69);
		list.add("tejaswi");
		System.out.println(list);
		//Modifying the ArrayList
		list.add(true);
		list.add(1,2);
		System.out.println(list);
		list.set(2, 4);
		System.out.println(list);
		list.add(7);
		list.add(2);
		System.out.println(list);
		//Performing some operations on the ArrayList
		System.out.println(list.indexOf('n'));
		System.out.println(list.contains(2));
		System.out.println(list.get(0));
		System.out.println(list.lastIndexOf(7));
		list.add(null);
		System.out.println(list.size());
		System.out.println(list.remove(8));
		System.out.println(list);
		System.out.println(list.remove(7.69));
		System.out.println(list.remove("tejaswi"));
		System.out.println(list);
		System.out.println(list.isEmpty());
		//Creating a new List and adding elements to it
		List<Object> l=new ArrayList<>();
		System.out.println(l.isEmpty());
		l.add(1);
		l.add(2);
		l.add(3);
		l.addAll(list);
		l.addAll(l);
		System.out.println(l);
	}

}
