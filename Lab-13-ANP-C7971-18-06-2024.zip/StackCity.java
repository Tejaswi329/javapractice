import java.util.Stack;

public class StackCity {

    public static void main(String[] args) {
        Stack<String> cityStack = new Stack<>();
        Stack<Integer> literacyRateStack = new Stack<>();

        // Pushing cities and their literacy rates onto the stacks
        cityStack.push("Khammam");
        literacyRateStack.push(70);

        cityStack.push("Karimnagar");
        literacyRateStack.push(80);

        cityStack.push("Hyderabad");
        literacyRateStack.push(83);

        // Retrieve the top city and its literacy rate
        if (!cityStack.isEmpty() && !literacyRateStack.isEmpty()) {
            String topCity = cityStack.peek();
            int topLiteracyRate = literacyRateStack.peek();
            System.out.println("Top City: " + topCity + " - Literacy Rate: " + topLiteracyRate);
        }

        // Search for a specific city in the list
        String searchCity = "Karimnagar";
        if (cityStack.contains(searchCity)) {
            System.out.println(searchCity + " is found in the list.");
        } else {
            System.out.println(searchCity + " is not found in the list.");
        }
    }
}