// Super class Employee
class Employee {
    String name;
    double baseSalary;

    // Method to calculate total salary
    public void totalSalary() {
        System.out.println("Calculating total salary for Employee: " + name);
    }
}

// Child class Permanent Employee
class PermanentEmployee extends Employee {
    double bonus;

    // Method overriding to calculate total salary for Permanent Employee
    @Override
    public void totalSalary() {
        double totalSalary = baseSalary + bonus;
        System.out.println("Total salary for Permanent Employee " + name + " is: " + totalSalary);
    }
}

// Child class Contract Employee
class ContractEmployee extends Employee {
    double hoursWorked;
    double hourlyRate;

    // Method overriding to calculate total salary for Contract Employee
    @Override
    public void totalSalary() {
        double totalSalary = hoursWorked * hourlyRate;
        System.out.println("Total salary for Contract Employee " + name + " is: " + totalSalary);
    }
}

public class PayrollSystem {
    public static void main(String[] args) {
        PermanentEmployee permanentEmployee = new PermanentEmployee();
        permanentEmployee.name = "Alice";
        permanentEmployee.baseSalary = 5000;
        permanentEmployee.bonus = 1000;
        permanentEmployee.totalSalary(); // Calculate total salary for Permanent Employee

        ContractEmployee contractEmployee = new ContractEmployee();
        contractEmployee.name = "Bob";
        contractEmployee.hoursWorked = 40;
        contractEmployee.hourlyRate = 25;
        contractEmployee.totalSalary(); // Calculate total salary for Contract Employee
    }
}