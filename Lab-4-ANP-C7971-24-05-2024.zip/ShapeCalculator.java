public class ShapeCalculator {

    // Overloaded method area() for calculating area of a square
    public double area(double side) {
        return side * side;
    }

    // Overloaded method area() for calculating area of a rectangle
    public double area(double length, double width) {
        return length * width;
    }

    public static void main(String[] args) {
        ShapeCalculator calculator = new ShapeCalculator();

        // Calculate and print the area of a square
        double squareArea = calculator.area(5.0);
        System.out.println("Area of the square: " + squareArea);

        // Calculate and print the area of a rectangle
        double rectangleArea = calculator.area(4.0, 6.0);
        System.out.println("Area of the rectangle: " + rectangleArea);

    }
}

