public class Main {
    public static void main(String[] args) {
        
        int a = 10;
        int b = 3;

        
        System.out.println("a + b = " + (a + b));

        
        System.out.println("a - b = " + (a - b));

        
        System.out.println("a * b = " + (a * b));

        
        System.out.println("a / b = " + ((double) a / b)); 

        
        System.out.println("a / b (integer division) = " + (a / b));

        
        System.out.println("a % b = " + (a % b));

        
        System.out.println("a ^ b = " + Math.pow(a, b));

        
        int x = 5;
        int y = 7;

        
        System.out.println("x > y: " + (x > y));

        
        System.out.println("x < y: " + (x < y));

        
        System.out.println("x >= y: " + (x >= y));

        
        System.out.println("x <= y: " + (x <= y));

      
        System.out.println("x == y: " + (x == y));

        
        System.out.println("x != y: " + (x != y));
    }
}
