package com.Collections;

import java.util.HashMap;

public class DemoHashMap {

    public static void main(String[] args) {
        // Creating a HashMap to store country codes
        HashMap<String, Integer> countrycodes = new HashMap<>();

        // Adding country codes to the HashMap
        countrycodes.put("US", 1);
        countrycodes.put("India", 91);
        countrycodes.put("Australia", 61);
        countrycodes.put("China", 86);
        countrycodes.put("Pakistan", 92);
        countrycodes.put(null, 0); // Adding a null key

        // Printing the HashMap
        System.out.println(countrycodes);
    }

}
