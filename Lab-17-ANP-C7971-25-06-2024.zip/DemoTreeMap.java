package com.Collections;

import java.util.TreeMap;

public class DemoTreeMap {

    public static void main(String[] args) {
        // Creating a TreeMap to store student objects with roll numbers as keys
        TreeMap<Integer, Student> studentMap = new TreeMap<>();
        
        // Creating student objects
        Student student1 = new Student("Hari", 101);
        Student student2 = new Student("Ganga", 102);
        Student student3 = new Student("Teja", 103);
        
        // Adding student objects to the TreeMap with roll numbers as keys
        studentMap.put(student1.getRollNumber(), student1);
        studentMap.put(student2.getRollNumber(), student2);
        studentMap.put(student3.getRollNumber(), student3);
        
        // Printing the TreeMap of student objects
        System.out.println(studentMap);
    }

    // Student class definition
    static class Student {
        private String name;
        private int rollNumber;
        
        public Student(String name, int rollNumber) {
            this.name = name;
            this.rollNumber = rollNumber;
        }
        
        public String getName() {
            return name;
        }
        
        public int getRollNumber() {
            return rollNumber;
        }
        
        @Override
        public String toString() {
            return "Student{" +
                    "name='" + name + '\'' +
                    ", rollNumber=" + rollNumber +
                    '}';
        }
    }

}
