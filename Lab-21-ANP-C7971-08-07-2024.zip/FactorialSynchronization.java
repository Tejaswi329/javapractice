package com.collections;

public class FactorialSynchronization {

    // This method calculates the factorial of a given number and prints the result. It is synchronized
    synchronized static void factorial(int num) {
        int fact = 1; // Initialize factorial variable

        // Calculate factorial using a for loop
        for (int i = 1; i <= num; i++) {
            fact = fact * i;
        }

        try {
            // Thread to sleep for 500 milliseconds
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Print the calculated factorial
        System.out.println("Factorial: " + fact);
    }
}
package com.collections;

public class SynchronizedFactorialDemo extends Thread {
    // Referring to the FactorialSynchronization class to access the synchronized factorial method
    FactorialSynchronization fse;

    // Constructor to initialize the FactorialSynchronization object
    public SynchronizedFactorialDemo(FactorialSynchronization fse) {
        super();
        this.fse = fse;
    }

    // Override the run method to call the factorial method on the FactorialSynchronization object
    public void run() {
        fse.factorial(5); // Calculate factorial of 5
    }

    public static void main(String[] args) {
        // Create an instance of FactorialSynchronization to access the synchronized factorial method
        FactorialSynchronization fs = new FactorialSynchronization();

        // Create three threads to demonstrate synchronization. Each thread will calculate the factorial of 5
        SynchronizedFactorialDemo sfd = new SynchronizedFactorialDemo(fs);
        sfd.start();

        SynchronizedFactorialDemo sfd1 = new SynchronizedFactorialDemo(fs);
        sfd1.start();

        SynchronizedFactorialDemo sfd2 = new SynchronizedFactorialDemo(fs);
        sfd2.start();
    }
}

