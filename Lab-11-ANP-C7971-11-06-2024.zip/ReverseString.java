package com.Anudip;
public class ReverseString {
    public static void main(String[] args) {
        // Define the original string
        String str = "narmala";
        // Initialize an empty string to store the reversed value
        String str1= "";
        // Iterate through the original string in reverse order
        for (int i = str.length() - 1; i >= 0; i--) {
            // Append each character to the reversed string
            str1+= str.charAt(i);
        }
      // Print the original and reversed strings
        System.out.println(str);
        System.out.println(str1);
    }
}