package com.Anudip;
public class StringBuilderStringBuffer {
    public static void main(String[] args) {
        // Using StringBuilder
        StringBuilder stringBuilder = new StringBuilder("anudip");
        stringBuilder.append(" foundation");
        System.out.println("Using StringBuilder: " + stringBuilder);

        // Using StringBuffer
        StringBuffer stringBuffer = new StringBuffer("hello");
        stringBuffer.append(" Java");
        System.out.println("Using StringBuffer: " + stringBuffer);
    }
}

