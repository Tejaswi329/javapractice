package com.Collections;

import java.util.TreeSet;

public class DemoTreeset {

	public static void main(String[] args) {
// Creating a new TreeSet to store integers
		TreeSet<Integer> t = new TreeSet<Integer>();
// Adding integers to the TreeSet
		t.add(7);
		t.add(9);
		t.add(6);
		t.add(8);
		t.add(3);
// Printing the TreeSet
		System.out.println(t);
// Printing the size of the TreeSet
		System.out.println(t.size());
// Printing the first element in the TreeSet
		System.out.println(t.first());
// Printing the last element in the TreeSet
		System.out.println(t.last());
// Printing the TreeSet again
		System.out.println(t);
		
		
		
		
		
		

	}

}
