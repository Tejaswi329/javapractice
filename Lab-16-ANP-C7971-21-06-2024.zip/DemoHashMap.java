package com.Collections;

import java.util.HashMap;

public class DemoHashMap {

	public static void main(String[] args) {
// Creating a HashMap to store city names with corresponding integer keys
		HashMap<Integer,String> cities=new HashMap<Integer,String> ();
// Adding city names to the HashMap with integer keys
		cities.put(1,"Indore");
		cities.put(2,"Surat");
		cities.put(3,"Navi Mumbai");
		cities.put(4,"Ambikapur");
		cities.put(5,"Mysuru");
// Printing the HashMap
		System.out.println(cities);
// Checking if a key is absent and adding a value if absent
		cities.putIfAbsent(4,"Ambikapur");
// Printing the size of the HashMap
		System.out.println(cities.size());
 // Checking if the HashMap contains a specific key

		System.out.println(cities.containsKey(3));
// Removing a key-value pair from the HashMap
		System.out.println(cities.remove(2));
 // Printing the HashMap after removal
		System.out.println(cities);
		
		
		
		

	}

}
