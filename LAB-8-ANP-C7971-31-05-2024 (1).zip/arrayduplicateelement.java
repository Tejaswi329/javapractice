//class declaration
public class arrayduplicateelement {
//main funtion
public static void main(String[] args) {
//declaring array elements
int[] arr={56,87,56,45,34,87,65};
int count=0;
//to check for duplicate values
for(int i=0;i<arr.length;i++) {
for(int j=i+1;j<arr.length;j++) {
if(arr[i]==arr[j]) {
//to print duplicate values
System.out.println(arr[j]);
count++;
}
}
}
//to print number of duplicate values 
System.out.println(count);
}
}
