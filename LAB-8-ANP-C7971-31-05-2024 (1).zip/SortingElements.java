//class declaration
public class SortingElements {
//main method 
public static void main(String[] args) {
//initialize array elements
int[] arr={23,12,67,45,97,54};
int i=0;
int j=0;
for(i=0;i<arr.length-1;i++) {
for(j=0;j<arr.length-i-1;j++) {
if(arr[j]<arr[j+1]) {
int temp=arr[j];
arr[j]=arr[j+1];
arr[j+1]=temp;
}
}
}
//printing sorted elements
System.out.println("Sorted Elements are:");
for(i=0;i<arr.length;i++) {
System.out.println(" "+arr[i]);
}
}
}