public class array {
public static void main(String args[]) {
int []array={4,7,3,1,2};
int min=array[0];
int max=array[0];
for(int i=0;i<array.length;i++) {
if(min>array[i]){
min=array[i];
}
if(max<array[i]) {
max=array[i];
}
}
System.out.println("minimum term is:"+min+,"maximum term is:"+max);
}
}
