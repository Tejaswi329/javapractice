// Parent class Transport
class Transport {
    String type;

    // Constructor
    public Transport(String type) {
        this.type = type;
    }

    // Method to display type
    public void displayType() {
        System.out.println("Type: " + type);
    }
}

// Subclass RoadTransport inheriting from Transport
class RoadTransport extends Transport {
    String roadType;

    // Constructor
    public RoadTransport(String type, String roadType) {
        super(type); // Call to parent class constructor
        this.roadType = roadType;
    }

    // Method to display road type
    public void displayRoadType() {
        System.out.println("Road Type: " + roadType);
    }
}

// Subclass FourWheeler inheriting from RoadTransport
class FourWheeler extends RoadTransport {
    int numberOfWheels;

    // Constructor
    public FourWheeler(String type, String roadType, int numberOfWheels) {
        super(type, roadType); // Call to parent class constructor
        this.numberOfWheels = numberOfWheels;
    }

    // Method to display number of wheels
    public void displayNumberOfWheels() {
        System.out.println("Number of Wheels: " + numberOfWheels);
    }
}

// Main class to test the program
public class Main {
    public static void main(String[] args) {
        // Creating an instance of FourWheeler
        FourWheeler car = new FourWheeler("Car", "Asphalt", 4);

        // Accessing attributes and methods of all levels of inheritance
        car.displayType();
        car.displayRoadType();
        car.displayNumberOfWheels();
    }
}
