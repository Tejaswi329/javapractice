// Parent class Shape
class Shape {
    String color;

    // Constructor
    public Shape(String color) {
        this.color = color;
    }

    // Method to display color
    public void displayColor() {
        System.out.println("Color: " + color);
    }
}

// Subclass Circle inheriting from Shape
class Circle extends Shape {
    int radius;

    // Constructor
    public Circle(String color, int radius) {
        super(color); // Call to parent class constructor
        this.radius = radius;
    }

    // Method to display radius
    public void displayRadius() {
        System.out.println("Radius: " + radius);
    }
}

// Main class to test the program
public class Main {
    public static void main(String[] args) {
        // Creating an instance of Circle
        Circle circle = new Circle("Blue", 5);

        // Accessing attributes and methods of both parent and subclass
        circle.displayColor();
        circle.displayRadius();
    }
}
