package com.collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

// Define the Student class implementing Comparable interface
class Student implements Comparable<Student> {
    private int studentId;
    private String studentName;
    private String course;

    // Constructor to initialize Student objects
    public Student(int studentId, String studentName, String course) {
        this.studentId = studentId;
        this.studentName = studentName;
        this.course = course;
    }

    // Compare students based on their names
    @Override
    public int compareTo(Student o) {
        return this.studentName.compareTo(o.studentName);
    }

    // String representation of Student object
    @Override
    public String toString() {
        return "Student{" +
                "studentId=" + studentId +
                ", studentName='" + studentName + '\'' +
                ", course='" + course + '\'' +
                '}';
    }
}

// Main class to demonstrate sorting of Student objects
public class StudentCollection {

    public static void main(String[] args) {
        // Create a list to store Student objects
        List<Student> studentList = new ArrayList<>();
        studentList.add(new Student(123, "Radha", "BSc"));
        studentList.add(new Student(231, "Krishna", "Bcom"));
        studentList.add(new Student(311, "Gopika", "Btech"));
        studentList.add(new Student(111, "Madhav", "BE"));
        studentList.add(new Student(141, "Hari", "BCA"));

        // Display students before sorting
        System.out.println("Students before sorting:");
        for (Student student : studentList) {
            System.out.println(student);
        }

        // Sort the list based on student names
        Collections.sort(studentList);

        // Display students after sorting based on names
        System.out.println("\nStudents after sorting based on name:");
        for (Student student : studentList) {
            System.out.println(student);
        }
    }
}