package com.Anudip;

//class declaration
public class ArrayMerge {

	public static void main(String[] args) {
		int[] arr1= {1,2,3,4};
		int[] arr2= {5,6,7,8,9};
		int a=arr1.length;
		int b=arr2.length;
		int[] mergedArr=new int[a+b];
               //copying elements of the first array
		for(int i=0;i<a;i++) {
			mergedArr[i]=arr1[i];
		}
                //copying elements of the second array
		for(int i=0;i<b;i++) {
			mergedArr[a+i]=arr2[i];
			
		}
		System.out.print("The Merged Array is:");
		for(int i=0;i<a+b;i++) {
			System.out.print(i+"");
		}
		
		
		

	}

}
