package com.Anudip;


public class ArraySort {

	
	public static void main(String[] args) {
		int arr[]= {3,2,8,7,6};
		int i,j,temp = 0;
		for(i=0;i<arr.length-1;i++) {
			for(j=0;j<arr.length-1;j++) {
				if(arr[j]>arr[j+1]) {
					temp=arr[j];
					arr[j]=arr[j+1];
					arr[j+1]=temp;
					
				}
			}
		}
		System.out.print("The sorted array is:");
		for(i=0;i<arr.length;i++) {
			System.out.print(arr[i]+"");
		}
        }
}