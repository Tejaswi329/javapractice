package com.Anudip;

public class StringMethods {
    public static void main(String[] args) {
        String str = "Hello, World!";

        // String methods
        int length = str.length();
        String upperCase = str.toUpperCase();
        String lowerCase = str.toLowerCase();
        boolean containsHello = str.contains("Hello");
        
        // Check if the character exists before replacing
        String str1;
        if (str.contains("o")) {
            str1 = str.replace('o', 'X');
        } else {
            str1 = "Character 'o' not found in the string.";
        }

        // Printing outputs
        System.out.println("Original String: " + str);
        System.out.println("Length of the String: " + length);
        System.out.println("Uppercase: " + upperCase);
        System.out.println("Lowercase: " + lowerCase);
        System.out.println("Contains 'Hello': " + containsHello);
        System.out.println("Replaced 'o' with 'X': " + str1);
    }
}
