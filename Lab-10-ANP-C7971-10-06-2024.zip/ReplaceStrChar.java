package com.Anudip;
//class declaration
public class ReplaceStrChar {
	public static void main(String[] args) {
//define a string
		String Str="98765432";
		String Str1=Str.replace("9876", "XXXX");
		
//printing replaced character string
		System.out.print(Str1);
	}
}
