public class AccessSpecifier {
    public int publicVar = 10;
    private int privateVar = 20;
    protected int protectedVar = 30;
    int defaultVar = 40;

    public static void main(String[] args) {
        AccessSpecifier example = new AccessSpecifier();
        System.out.println("Public variable: " + example.publicVar);
        // System.out.println("Private variable: " + example.privateVar); // This will cause an error as privateVar is not accessible here
        System.out.println("Protected variable: " + example.protectedVar);
        System.out.println("Default variable: " + example.defaultVar);
    }
}