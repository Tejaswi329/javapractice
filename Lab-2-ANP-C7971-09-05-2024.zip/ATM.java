import java.util.Scanner;
public class ATM {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double dailyLimit = 500; // Example daily withdrawal limit
        double totalWithdrawn = 0;
        while (true) {
            System.out.print("Enter the amount to withdraw (0 to exit): ");
            double amount = scanner.nextDouble();
            if (amount == 0) {
                System.out.println("Exiting ATM application. Have a nice day!");
                break; 
            }
            if (totalWithdrawn + amount > dailyLimit) {
                System.out.println("Daily withdrawal limit exceeded. Exiting ATM application.");
                break; 
            }
            totalWithdrawn += amount;
            System.out.println("Amount withdrawn: " + amount);
            System.out.println("Total withdrawn today: " + totalWithdrawn);
        }
    }
}
