package com.exe;
//BankingApp class to simulate a simple banking application
public class BankingApp {
	int accountNo;//Variable to store the account number
	int balance;//Variable to store the account balance
	//Constructor to initialize account number and balance
	public BankingApp(int accountNo, int balance) {
		super();
		this.accountNo=accountNo;
		this.balance=balance;
	}
	//Method to deposit money into the account
	void deposit(int amt) {
		balance+=amt;//Add the deposited amount to the balance
		System.out.println("New Balance:"+amt);//Print the new balance after deposit
	}
	//Method to withdraw money from the account, throws InsufficientBalanceException if balance is not enough
	void withDraw(int amt) throws InsufficientBalanceException{
		if(balance>amt+1000) {
			balance-=amt;
			System.out.println("Amount withdrawn successfully"+amt+"\n New Balance:"+balance);//Print success message and new balance
		}
		else {
			throw new InsufficientBalanceException("Insufficient Balance");//Throw exception for insufficient balance
		}
		}
	//Main method to test the banking operations
	public static void main(String[] args) {
		BankingApp bankingApp=new BankingApp(1234567,300000);//Create a new BankingApp object
		bankingApp.deposit(10000);//Deposit 10000 into the account
		try {
			bankingApp.withDraw(309999);//Attempt to withdraw 309999 from the account
			} catch (InsufficientBalanceException e) {
			System.out.println(e);//Catch and print the insufficient balance exception
		}
		}
}