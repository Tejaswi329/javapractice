package com.Collections;

import java.util.ArrayDeque;

public class DemoArrayDeque {

	public static void main(String[] args) {
//Creating a new ArrayDeque to store integers
		ArrayDeque<Integer> arque=new ArrayDeque<Integer>();
//Adding elements to the front of the deque
		arque.push(10);
		arque.push(20);
		arque.push(30);
		arque.push(40);
//Displaying the elements in the deque
		System.out.println(arque);
//Getting the size of the deque
		System.out.println(arque.size());
//Removing and returning the first element of the deque
		System.out.println(arque.poll());
//Popping and returning the top element of the deque
		System.out.println(arque.pop());
//Peeking at the top element of the deque without removing it
		System.out.println(arque.peek());
//Adding elements to the front and end of the deque
		arque.addFirst(90);
		arque.addLast(9);
//Displaying the updated deque
		System.out.println(arque);
	}
}