package com.Collections;

import java.util.PriorityQueue;

public class QueueDemo {

	public static void main(String[] args) {
//Creating a PriorityQueue to store integers
		 PriorityQueue<Integer> pq = new PriorityQueue<Integer>();
//Adding elements to the priority queue
		 pq.add(10);
		 pq.add(20);
		 pq.add(30);
		 pq.add(40);
//Displaying the entire priority queue
		 System.out.println(pq);
//Peeking at the head of the priority queue(without removing)
		 System.out.println(pq.peek());
//Polling and displaying the head of the priority queue(removing)
		 System.out.println(pq.poll());
//Displaying the updated priority queue after polling an element
		 System.out.println(pq);
//Adding another element(10) to the priority queue
		 pq.add(10);
		 System.out.println(pq);
		
	}
}