package com.exe;
class Order {
    boolean paymentDone = false;

    // Method for the customer thread to place the order
    synchronized void placeOrder() {
        System.out.println("Order placed successfully. Waiting for payment...");
        paymentDone = false;
        notify(); // Notify the payment thread to process the payment
    }

    // Method for the payment thread to complete the payment
    synchronized void makePayment() {
        if (!paymentDone) {
            try {
                System.out.println("Processing payment...");
                Thread.sleep(2000); // Simulating payment processing time
                paymentDone = true;
                System.out.println("Payment completed successfully. Order confirmed!");
                notify(); // Notify the customer thread that payment is done
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

public class OrderProcessing {
    public static void main(String[] args) {
        Order order = new Order();

        // Customer thread
        Thread customerThread = new Thread(() -> {
            synchronized (order) {
                try {
                    order.wait(); // Wait for the payment to be completed
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                order.makePayment(); // Proceed to make payment
            }
        });

        // Payment thread
        Thread paymentThread = new Thread(() -> {
            order.placeOrder(); // Place the order
            synchronized (order) {
                try {
                    order.wait(); // Wait for the customer to confirm payment completion
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });

        // Start the threads
        customerThread.start();
        paymentThread.start();
    }
}