package com.Anudip;
//Define an enumeration of different departments
enum Department {
	Accounts,
	Devops,
	Testing,
	HR
}
//Class to demonstrate the usage of enums
public class DemoEnum {

	public static void main(String[] args) {
//Assign the value Department.Testing to variable d
		Department d=Department.Testing;
//Assign the value Department.Accounts to variable d1
                Department d1=Department.Accounts;
//Print the value of variable d
		System.out.println(d);
//Compare the ordinal values of d and d1
		System.out.println(d.compareTo(d1));
//Check if d is equal to d1
		System.out.println(d.equals(d1));
		

	}

}
