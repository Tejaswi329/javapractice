// Define the Employee class
class Employee {
    String name;
    int id;
    
    // Constructor to initialize Employee objects
    public Employee(String name, int id) {
        this.name = name;
        this.id = id;
    }
}

public class EmployeeArray {
    public static void main(String[] args) {
        // Create an array to hold Employee objects
        Employee[] employees = new Employee[2];
        
        // Initialize each Employee object in the array
        employees[0] = new Employee("radha", 1001); // Employee 1
        employees[1] = new Employee("krishna", 1002); // Employee 2
        
        // Print details of each Employee
        for (Employee emp : employees) {
            System.out.println("Employee Name: " + emp.name + ", Employee ID: " + emp.id);
        }
    }
}